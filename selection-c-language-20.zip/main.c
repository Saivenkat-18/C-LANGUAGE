//Program To Print Discount and Actual Amount

#include <stdio.h>

int main()
{
    float sales, discount, actualAmount;

    printf("Enter the sales amount: ");
    scanf("%f", &sales);

    if (sales >= 25000)
    {
        discount = 0.25;
    }
    else if (sales >= 20000 && sales < 25000) 
    {
        discount = 0.20;
    }
    else if (sales >= 10000 && sales < 20000)
    {
        discount = 0.10;
    } 
    else if (sales >= 5000 && sales < 10000) 
    {
        discount = 0.05;
    } 
    else
    {
        discount = 0.0;
    }

    float discountAmount = sales * discount;

    actualAmount = sales - discountAmount;

    printf("Discount: %.2f%%\n", discount * 100);
    printf("Actual Amount: %.2f\n", actualAmount);

    return 0;
}

