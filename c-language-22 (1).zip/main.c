//Program To Check Whether A Person Is Qualified To Be A Programmer

#include<stdio.h>

int main()

{
    int noofprgms;
    
    printf("Enter No Of Programs Completed By The Person : ");
    scanf("%d",&noofprgms);
    
    if(noofprgms>25)
    {
        printf("You Are Qualified.");
        printf("\nCongratulations...");
    }
      else
      {
        printf("You Are Not Qualified.");
        printf("\nBetter Luck Next Time...");
      }
      
      return 0;
}
