#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isPalindrome(char *str)
{
    int left = 0;
    int right = strlen(str) - 1;

    while (right > left)
    {
     
        while (!isalnum(str[left]) && left < right)
        {
            left++;
        }
        while (!isalnum(str[right]) && right > left) 
        {
            right--;
        }

        if (tolower(str[left]) != tolower(str[right]))
        {
            return 0; 
        }
        
        left++;
        right--;
    }

    return 1; 
}

int main()
{
    char vehicleNumber[100];

    printf("Enter the vehicle number: ");
    scanf("%s", vehicleNumber);

    if (isPalindrome(vehicleNumber)) 
    {
        printf("%s is a palindrome.\n", vehicleNumber);
    }
    else
    {
        printf("%s is not a palindrome.\n", vehicleNumber);
    }

    return 0;
}
