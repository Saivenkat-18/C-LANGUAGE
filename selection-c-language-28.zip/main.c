//Program To Display Pass or Fail

#include <stdio.h>

int checkPass(int marksC, int marksCpp, int marksJava)
{
    return (marksC >= 35) && (marksCpp >= 35) && (marksJava >= 35);
}

void printFailedSubjects(int marksC, int marksCpp, int marksJava)
{
    if (marksC < 35) 
    {
        printf("Failed in C.\n");
    }
    if (marksCpp < 35) 
    {
        printf("Failed in C++.\n");
    }
    if (marksJava < 35) 
    {
        printf("Failed in Java.\n");
    }
}

int main()
{
    int marksC, marksCpp, marksJava;
    int total;
    float average;
    char grade[20];

    // Input marks from the user
    printf("Enter marks in C: ");
    scanf("%d", &marksC);
    printf("Enter marks in C++: ");
    scanf("%d", &marksCpp);
    printf("Enter marks in Java: ");
    scanf("%d", &marksJava);

    if (checkPass(marksC, marksCpp, marksJava))
    {
     
        total = marksC + marksCpp + marksJava;
        average = total / 3.0;

        if (average >= 70) 
        {
            sprintf(grade, "First Class");
        }
        else 
        if (average >= 50) 
        {
            sprintf(grade, "Second Class");
        }
        else if (average >= 35)
        {
            sprintf(grade, "Pass Class");
        } 
        else
        {
            sprintf(grade, "No Grade");
        }

        printf("Total Marks: %d\n", total);
        printf("Average Marks: %.2f\n", average);
        printf("Class: %s\n", grade);
    } 
    else 
    {
        printFailedSubjects(marksC, marksCpp, marksJava);
        printf("No Grade.\n");
    }

    return 0;
}
