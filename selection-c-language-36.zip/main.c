#include <stdio.h>

int main()
{
    int num1, num2;

    printf("Enter the first integer: ");
    scanf("%d", &num1);
    printf("Enter the second integer: ");
    scanf("%d", &num2);

    if (num1 < num2) {
        printf("up\n");
    } else if (num1 > num2) {
        printf("down\n");
    } else {
        printf("equal\n");
    }

    return 0;
}
