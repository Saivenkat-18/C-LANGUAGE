#include <stdio.h>
#include <stdlib.h>

int findHCF(int a, int b) 
{
    if (b == 0) 
    {
        return a;
    }
    return findHCF(b, a % b);
}

int findLCM(int a, int b) {
    int hcf = findHCF(a, b);
    return abs(a * b) / hcf;
}

int main()
{
    int num1, num2, lcm;

    printf("Enter two integers: ");
    scanf("%d %d", &num1, &num2);

    lcm = findLCM(num1, num2);

    printf("LCM of %d and %d is %d\n", num1, num2, lcm);

    return 0;
}
