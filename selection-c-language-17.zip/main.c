#include <stdio.h>

int isLeapYear(int year)

{
    if (year % 400 == 0)
    {
        return 1;
    }
    else if (year % 100 == 0)
    {
        return 0;
    } 
    else if (year % 4 == 0) 
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main() 

{
    int day, month, year;

    printf("Enter your date of birth (dd mm yyyy): ");
    scanf("%d %d %d", &day, &month, &year);

    if (isLeapYear(year)) {
        printf("You were born in a leap year.\n");
    } else {
        printf("You were not born in a leap year.\n");
    }

    return 0;
}
