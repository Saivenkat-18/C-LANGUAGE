//Program To Display Which View Does A Building WIth 50 Floors Get

#include <stdio.h>

int main()
{
    int floorNumber;

    printf("Enter your floor number: ");
    scanf("%d", &floorNumber);

    if (floorNumber > 50)
    {
        printf("We have only 50 floors\n");
    }
    else if (floorNumber % 2 == 0)
    {
        printf("Hey you have Beach view for your flat.\n");
    }
    else
    {
        printf("Hey you have Forest view for your flat.\n");
    }

    return 0;
}
