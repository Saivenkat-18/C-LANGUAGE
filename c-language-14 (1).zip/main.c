//Program To Convert Rupees To Paise

#include<stdio.h>

int main()

{
    int rupees,paise;
    
    printf("Enter The Value In Rupees : ");
    scanf("%d",&rupees);
    
    paise=rupees*100;
    
    printf("Value In Paise Is : %d",paise);
    
    return 0;
}