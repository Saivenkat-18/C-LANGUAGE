//To Display Travelling Time From Minutes To Hours and Minutes

#include <stdio.h>

int main() 
{
    int hours, minutes, totalminutes;

    // Input
    printf("Enter the Total Flying Time From Hyderabad to Singapore in Minutes : ");
    scanf("%d", &totalminutes);

    // Process : Calculation
    hours = totalminutes / 60;
    minutes = totalminutes % 60;

    // Output
    printf("The Flying Time is %d Hours and %d Minutes.\n", hours, minutes);

    return 0;
}