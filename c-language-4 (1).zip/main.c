//To Calculate Average and Total Marks

#include<stdio.h>

int main()

{
    float english,maths,sanskrit,physics,chemistry;
    float totalmarks,averagemarks;
    
    //Input
    printf("Enter Marks of English :");
    scanf("%f",&english);
    
    printf("Enter Marks of Sanskrit :");
    scanf("%f",&sanskrit);
    
    printf("Enter Marks of Maths :");
    scanf("%f",&maths);
    
    printf("Enter Marks of Physics :");
    scanf("%f",&physics);
    
    printf("Enter Marks of Chemistry :");
    scanf("%f",&chemistry);
    
    //Process
    totalmarks=english+sanskrit+maths+physics+chemistry;
    averagemarks=totalmarks/5;
    
    //Output
    printf("Total Marks : %.2f\n",totalmarks);
    printf("Average Marks : %.2f\n",averagemarks);
    
    return 0;
}