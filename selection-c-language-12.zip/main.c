//Program To Display Which Movie Is A Hit

#include <stdio.h>

int main()
{
 
    float rating1, rating2, rating3;

    printf("Enter the Rating for Movie 1 : ");
    scanf("%f", &rating1);
    printf("Enter the Rating for Movie 2 : ");
    scanf("%f", &rating2);
    printf("Enter the Rating for Movie 3 : ");
    scanf("%f", &rating3);
    
    if (rating1 > 7.5)
    {
        printf("Movie 1 is a Hit\n");
    }
    if (rating2 > 7.5) 
    {
        printf("Movie 2 is a Hit\n");
    }
    if (rating3 > 7.5) 
    {
        printf("Movie 3 is a Hit\n");
    }

    if (!(rating1 > 7.5) && !(rating2 > 7.5) && !(rating3 > 7.5)) 
    {
        printf("No movie is a Hit\n");
    }

    return 0;
}
