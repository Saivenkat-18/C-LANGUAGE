#include<stdio.h>
#include<string.h>

int main ()
{
  char name[50];
  int len, count = 1;
  printf ("Enter Your Name : ");
  scanf ("%s", &name);

  len =strlen(name);

  while (count <= len)

	{
	  printf ("\n %d.%s",count, name);
	  count++;

	}
  printf ("\n");

  return 0;

}
