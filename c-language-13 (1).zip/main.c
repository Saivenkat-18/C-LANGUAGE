//Program To Convert Fahrenheit Scale To Centigrade Scale

#include<stdio.h>

int main()

{
    float celsius,fahrenheit;
    
    printf("Enter The Temperature In Fahrenheit Scale : ");
    scanf("%f",&fahrenheit);
    
    celsius=(fahrenheit-32)*5/9;
    
    printf("Temperature In Celsius Scale Is : %.2f\n",celsius);
    
    return 0;
}
