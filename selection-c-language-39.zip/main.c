#include <stdio.h>

int main()
{
    char signal;

    printf("Enter the traffic signal (R, Y, G): ");
    scanf(" %c", &signal);

    switch (signal)
    {
        case 'R':
        case 'r':
            printf("RED Light: Please STOP\n");
            break;
        case 'Y':
        case 'y':
            printf("YELLOW Light: Please Check and Go\n");
            break;
        case 'G':
        case 'g':
            printf("GREEN Light: Please GO\n");
            break;
        default:
            printf("There is no signal point\n");
            break;
    }

    return 0;
}
