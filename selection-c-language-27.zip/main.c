//Program To Generate Bill

#include <stdio.h>

float calculateFinalBill(float price, char paymentMethod, int days) {
    float finalBill = price;

    if (paymentMethod == 'C') 
    { 
        finalBill = price - (price * 0.25);
    } 
    else if (paymentMethod == 'R') 
    {
        if (days <= 7) 
        {
            finalBill = price - (price * 0.15);
        } 
        else
        {
            finalBill = price + (price * 0.10);
        }
    }

    return finalBill;
}

int main()
{
    float price;
    char paymentMethod;
    int days;

    printf("Enter the price of the Smart TV: ");
    scanf("%f", &price);
    printf("Enter the payment method (C for Cash, R for Credit): ");
    scanf(" %c", &paymentMethod);

    if (paymentMethod == 'R')
    {
        printf("Enter the number of days within which the credit was paid: ");
        scanf("%d", &days);
    }
    else
    {
        days = 0; 
    }

    float finalBill = calculateFinalBill(price, paymentMethod, days);

    printf("The final bill amount is: %.2f\n", finalBill);

    return 0;
}
