//Program To Check The Type Of Character Inputted

#include <stdio.h>
#include <ctype.h>

int main()
{
    char ch;

    // Input a character
    printf("Enter a character: ");
    scanf("%c", &ch);

    // Check and output the type of character
    if (isupper(ch))
    {
        printf("The character '%c' is a capital letter.\n", ch);
    } 
    else if (islower(ch))
    {
        printf("The character '%c' is a small letter.\n", ch);
    }
    else if (isdigit(ch)) 
    {
        printf("The character '%c' is a digit.\n", ch);
    }
    else 
    {
        printf("The character '%c' is a special character.\n", ch);
    }

    return 0;
}
