//Program To Check If A Number Is Divisible By 2 Numbers

#include <stdio.h>

int main()
{
    int num;

    printf("Enter A Number : ");
    scanf("%d", &num);
   
    if (num % 3 == 0 && num % 5 == 0)
    {
        printf("The Number %d is Divisible by Both 3 and 5.\n", num);
    } 
    else
    {
        printf("The Number %d is not Divisible by Both 3 and 5.\n", num);
    }

    return 0;
}
