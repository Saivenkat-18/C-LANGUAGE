//Program To Prepare Electricity Bill

#include <stdio.h>

float calculateDomesticBill(int units) 
{
    float bill = 0.0;

    if (units < 100) 
    {
        bill = 100;
    }
    else 
    if (units <= 200)
    {
        bill = 100 + (units - 100) * 1.50;
    }
    else
    if (units <= 300)
    {
        bill = 100 + 100 * 1.50 + (units - 200) * 3.00;
    }
    else 
    {
        bill = 100 + 100 * 1.50 + 100 * 3.00 + (units - 300) * 5.00;
    }

    return bill;
}

float calculateCommercialBill(int units) 
{
    float bill = 0.0;

    if (units < 100) {
        bill = 150;
    } else if (units <= 200) {
        bill = 150 + (units - 100) * 2.50;
    } else if (units <= 300) {
        bill = 150 + 100 * 2.50 + (units - 200) * 4.50;
    } else {
        bill = 150 + 100 * 2.50 + 100 * 4.50 + (units - 300) * 7.50;
    }

    return bill;
}

int main() 
{
    int units;
    char connectionType;
    float bill = 0.0;

    printf("Enter the number of units consumed: ");
    scanf("%d", &units);

    printf("Enter the type of connection (D for Domestic, C for Commercial): ");
    scanf(" %c", &connectionType);

    if (connectionType == 'D' || connectionType == 'd')
    {
        bill = calculateDomesticBill(units);
    } 
    else
    if (connectionType == 'C' || connectionType == 'c')
    {
        bill = calculateCommercialBill(units);
    }
    else
    {
        printf("Invalid connection type!\n");
        return 1;
    }

    printf("The total bill is: Rs. %.2f\n", bill);

    return 0;
}
