#include <stdio.h>

int findhcf(int a, int b)
{
    if (b == 0)
    {
        return a;
    }
    return findhcf(b, a % b);
}

int main() 
{
    int num1, num2, hcf;

    printf("Enter two integers: ");
    scanf("%d %d", &num1, &num2);

    if (num1 < num2)
    {
       
        int temp = num1;
        num1 = num2;
        num2 = temp;
    }

    hcf = findhcf(num1, num2);

    printf("HCF of %d and %d is %d\n", num1, num2, hcf);

    return 0;
}
