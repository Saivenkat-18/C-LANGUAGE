#include <stdio.h>

int main() 
{
    char grade;

    printf("Enter the grade code (S, A, B, Y, F): ");
    scanf(" %c", &grade);

    switch (grade) {
        case 'S':
            printf("SUPER\n");
            break;
        case 'A':
            printf("VERY GOOD\n");
            break;
        case 'B':
            printf("FAIR\n");
            break;
        case 'Y':
            printf("ABSENT\n");
            break;
        case 'F':
            printf("FAIL\n");
            break;
        default:
            printf("Invalid grade code!\n");
            break;
    }

    return 0;
}
