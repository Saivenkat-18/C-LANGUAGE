#include <stdio.h>

int main() 
{
    int no;

    printf("Enter a number: ");
    scanf("%d", &no);

    for (int i = 0; i < no; i++)
    {
        printf("%d\n", no);
    }

    return 0;
}
