//Program To Check The Eligibility To Cast A Vote

#include<stdio.h>

int main()

{
    int age=0;
    
    printf("Enter The Age Of Voter : ");
    scanf("%d",&age);
    
    if(age>=18)
          printf("Congratulations! You Are Eligible To Vote");
    else
          printf("Oops!You Are Too Young To Vote");
          
    return 0;
}


