//Program To Read Two Numbers and Display their Difference

#include<stdio.h>

int main()

{
    int n1,n2,diff=0;
    
    printf("Enter First Number : ");
    scanf("%d",&n1);
    
    printf("Enter Second Number : ");
    scanf("%d",&n2);
    
    if(n1>=n2)
    diff=n1-n2;
     
     else 
      if(n2>=n1)
     {
         diff=n2-n1;
     }
     printf("Difference Between %d and %d is %d\n ",n1,n2,diff);
     
     return 0;
}