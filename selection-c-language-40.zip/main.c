#include <stdio.h>

int main()
{
    char grade;

    printf("Enter the grade (E, V, G, A, F): ");
    scanf(" %c", &grade);

    switch (grade) 
    {
        case 'E':
            printf("EXCELLENT\n");
            break;
        case 'V':
            printf("VERY GOOD\n");
            break;
        case 'G':
            printf("GOOD\n");
            break;
        case 'A':
            printf("AVERAGE\n");
            break;
        case 'F':
            printf("FAIL\n");
            break;
        default:
            printf("Invalid grade! Please enter E, V, G, A, or F.\n");
            break;
    }

    return 0;
}
