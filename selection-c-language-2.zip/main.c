//Program To Display The Price Of 2 Mobile Phones

#include<stdio.h>

int main()

{
    int samprice,vivoprice;
    
    printf("Enter The Price Of Samsung Mobile : ");
    scanf("%d",&samprice);
    
    printf("Enter The Price Of Vivo Mobile : ");
    scanf("%d",&vivoprice);
    
    if(samprice>vivoprice)
    
        printf("Samsung Mobile Is Costlier");
        else
        if(vivoprice>samprice)
        printf("Vivo Mobile Is Costlier");
        else
        printf("Both Are At Same Price");
   
    return 0;
}