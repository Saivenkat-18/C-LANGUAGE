//Program To Display Capital Alphabets Into Lower Case Alphabets

#include<stdio.h>

int main()

{
    char capletter,lwrletter;
    
    printf("Enter A Capital Alphabet : ");
    scanf("%c",&capletter);
    
    lwrletter=capletter+32;
    
    printf("Lower Case Alphabet : %c\n",lwrletter);
    
    return 0;
}