#include <stdio.h>

int main() 
{
    int tablenumber, start, end;

    printf("Enter the table number: ");
    scanf("%d", &tablenumber);

    printf("Enter the starting value: ");
    scanf("%d", &start);

    printf("Enter the ending value: ");
    scanf("%d", &end);

    printf("Multiplication table of %d from %d to %d:\n", tablenumber, start, end);
    for(int i = start; i <= end; i++)
    {
        printf("%d x %d = %d\n", tablenumber, i, tablenumber * i);
    }

    return 0;
}
