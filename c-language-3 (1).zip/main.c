#include <stdio.h>

int main() 
{
    float billamt, amtpaid, balance_amt;

    // Input 
    printf("Enter the Bill Amount : ");
    scanf("%f", &billamt);

    printf("Enter the Amount Paid By The Customer : ");
    scanf("%f", &amtpaid);

    //Process
    balance_amt = amtpaid - billamt;

    //Output
    printf("Balance to be returned : %.2f\n", balance_amt);

    return 0;
}