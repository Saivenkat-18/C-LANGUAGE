//Program To Display Marks Of 3 Subjects

#include <stdio.h>

int main() {
    float marks1, marks2, marks3, total, average;
    char grade;

    // Input marks for three subjects
    printf("Enter marks for Subject 1: ");
    scanf("%f", &marks1);
    printf("Enter marks for Subject 2: ");
    scanf("%f", &marks2);
    printf("Enter marks for Subject 3: ");
    scanf("%f", &marks3);

    // Calculate total and average
    total = marks1 + marks2 + marks3;
    average = total / 3;

    // Determine grade based on average
    if (average > 90)
    {
        grade = 'A+';
    }
    else if (average >= 80 && average <= 90)
    {
        grade = 'A';
    }
    else if (average >= 70 && average < 80) 
    {
        grade = 'B+';
    } 
    else if (average >= 60 && average < 70)
    {
        grade = 'B';
    }
    else if (average >= 50 && average < 60) 
    {
        grade = 'C';
    }
    else 
    {
        grade = 'F';
    }

    // Output total, average, and grade
    printf("Total Marks: %.2f\n", total);
    printf("Average Marks: %.2f\n", average);
    printf("Grade: %c\n", grade);

    return 0;
}