//To Calculate The Cost Of An iPhone and a Cover Case.

#include<stdio.h>

int main()
{
    int ph_price,case_price,totalbill;
    //Input: Price of iPhone
    
    printf("Enter The Price Of iPhone :");
    scanf("%d",&ph_price);
    
    printf("Enter The Price of Cover Case :");
    scanf("%d",&case_price);
    
    //Process
    totalbill= ph_price+case_price;
    
    //Output: Total Bill
    printf("Total Bill: %d\n",totalbill);
    
    return 0;
}
