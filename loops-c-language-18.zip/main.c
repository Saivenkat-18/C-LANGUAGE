#include <stdio.h>

int main() 
{
    int number;
    int countEven = 0, countOdd = 0;
    int sum = 0;

    printf("Enter numbers (enter 0 to stop):\n");

    while (1) 
    {
        printf("Enter number: ");
        scanf("%d", &number);

        if (number == 0)
        {
            break;
        }

        sum += number;

        if (number % 2 == 0) 
        {
            countEven++;
        }
        else 
        {
            countOdd++;
        }
    }

    printf("\nResults:\n");
    printf("Number of even numbers: %d\n", countEven);
    printf("Number of odd numbers: %d\n", countOdd);
    printf("Sum of all numbers: %d\n", sum);

    return 0;
}
