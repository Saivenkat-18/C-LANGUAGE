//Program To Display Age Of 2 People

#include<stdio.h>

int main()

{
    int p1,p2;
    char n1[50],n2[50];
    
    printf("Enter Name Of 1st Person : ");
    scanf("%s",&n1);
    
    printf("Enter Name Of 2nd Person : ");
    scanf("%s",&n2);
    
    printf("Enter Age Of 1st Person : ");
    scanf("%d",&p1);
    
    printf("Enter Age Of 2nd Person : ");
    scanf("%d",&p2);
    
    if(p1>p2)
       {
           printf("%s is Older Than %s",n1,n2);
       }
    else
    if(p1<p2)
    {
        printf("%s Is Older Than %s",n2,n1);
    }
    else
    {
        printf("%s and %s are of Same Age",n1,n2);
    }
    return 0;
    
}