//Program To Display Total Travelling Time From kilometers To meters.

#include<stdio.h>

int main()

{
    float km,m;
    
    printf("Enter Total Distance Travelled From A To B in Kilometers : ");
    scanf("%f",&km);
    
    m=km*1000;
    
    printf("Distance Travelled In Meters Is : %.2f",m);
    
    return 0;
}

