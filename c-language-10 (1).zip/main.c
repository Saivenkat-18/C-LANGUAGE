//To Print Name, Gender and Native Place of a Person

#include<stdio.h>
int main()

{
   char name,ggn,nativeplace;
   
   printf("Enter Your Full Name : Raj Jain");
   scanf("%c",&name);
   
   printf("Enter Your Gender(M/F) : M");
   scanf("%c",&ggn);
   
   printf("Enter Your Native place : Rajasthan");
   scanf("%c",&nativeplace);
   
   //Output
   printf("Name-Gender-Place of A Person : Raj Jain - M - Rajasthan");
  
   
   
   
   return 0;
}




