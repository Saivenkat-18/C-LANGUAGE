//Program To Display Text In The Centre Of Screen

#include<stdio.h>

int main()

{
    printf("\t\t\t\t AH CAREER \n\t\t\t\t Danavaipeta \n\t\t\t\t Rajahmundry");
    
    return 0;
}
