//Program To Check Vowel and Consonants

#include <stdio.h>
#include <ctype.h>

int main()
{
    char ch;

    // Input a character
    printf("Enter a character: ");
    scanf("%c", &ch);

    // Convert character to uppercase
    ch = toupper(ch);

    // Check if the character is a vowel or consonant
    if ((ch >= 'A' && ch <= 'Z')) 
    {
        if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
        {
            printf("The character '%c' is a vowel.\n", ch);
        } 
        else
        {
            printf("The character '%c' is a consonant.\n", ch);
        }
    } 
    else
    {
        printf("The character '%c' is not a letter.\n", ch);
    }

    return 0;
}
