#include <stdio.h>

int main()
{
    int num, isPrime = 1, iterations = 0;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (num < 2)
    {
        isPrime = 0;
        iterations = 1;
    }
    else 
    {
        for (int i = 2; i * i <= num; i++)
        {
            iterations++;
            if (num % i == 0) 
            {
                isPrime = 0;
                break;
            }
        }
        iterations++;
    }

    if (isPrime)
    {
        printf("%d is a prime number.\n", num);
    }
    else
    {
        printf("%d is not a prime number.\n", num);
    }

    printf("Number of iterations: %d\n", iterations);

    return 0;
}
