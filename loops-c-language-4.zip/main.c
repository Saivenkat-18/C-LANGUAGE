# include<stdio.h>

int main()

{
    char alpha;
    
    printf("Alphabets From A to Z : ");
    
    for(alpha= 'A' ; alpha <= 'Z';alpha++)
    {
        printf("%c\t",alpha);
    }
    
    printf("\n");
    
    return 0;
}