//Program To Calculate Area Of Circle

#include<stdio.h>

int main()

{
    float radius,area;
    radius=area=0;
    float pi=3.14;
    
    printf("Enter The Value Of Radius : ");
    scanf("%f",&radius);
    
    area=pi*radius*radius;
    
    printf("Area Of Circle Is : %2f",area);
    
    return 0;
}
