#include<stdio.h>

int main()

{
    int base,power,c,res;
    char ch = 't';
    c=base=power=0;
    
    while(ch=='t')
    {
        res=1;
        printf("Enter Base and Power : ");
        scanf("%d%d",&base,&power);
        for(c=1;c<=power;c++)
        res=res*base;
        
        printf("%d power %d is : %d",base,power,res);
    
    }
    return 0;
}