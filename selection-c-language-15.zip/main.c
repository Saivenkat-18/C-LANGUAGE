//Program To Read A Character And Check The Type Of Character It Is

#include<stdio.h>

int main()

{
    char ch;
    
    printf("Enter Any Character : ");
    scanf("%c",&ch);
    
    if(ch>=65 && ch<=90)
    printf("It Is An Uppercase Letter",ch);
    
    else
    if(ch>=97 && ch<=122)
    printf("It Is A Lowercase Letter",ch);
    else 
    if(ch>=48 && ch<=57)
    printf("It Is A Digit",ch);
    
    else
    printf("It Is A Special Character",ch);
    
    printf("\n");

    return 0;
}