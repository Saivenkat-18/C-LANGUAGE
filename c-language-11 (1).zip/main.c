//To Read Roll No,Name,Gender&Height of a Person

#include<stdio.h>

int main()

{
   int rollno;
   double height;
   char name[20];
   char gender;
   
   printf("Enter Roll No :");
   scanf("%d",&rollno);
   
   printf("Enter Height :");
   scanf("%lf",&height);
   
   printf("Enter Name :");
   scanf("%s",&name);
   
   printf("Enter Gender(M/F) :");
   scanf(" %c",&gender);
   
   printf("\nMemory Occupied by Each Variable:\n");
    printf("Size of rollno (int): %zu bytes\n", sizeof(rollno));
    printf("Size of name (char): %zu bytes\n", sizeof(name));
    printf("Size of gender (float): %zu bytes\n", sizeof(gender));
    printf("Size of height (double): %zu bytes\n", sizeof(height));
   
   return 0;
}




