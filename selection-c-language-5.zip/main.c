//Program To Check Whether The Number Is Positive or Negative

#include<stdio.h>

int main()

{
    int no=0;
    
    printf("Enter A Number : ");
    scanf("%d",&no);
    
    if(no>0)
    printf("The Number Is Positive");
    else
    if(no<0)
    printf("The Number Is Negative");
    else
    if(no==0)
    printf("The Number is Neither Positive Nor Negative");
    
    return 0;
}