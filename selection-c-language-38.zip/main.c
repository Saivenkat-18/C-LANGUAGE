#include <stdio.h>

int isLeapYear(int year)
{
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) 
    {
        return 1;
    }
    else
    {
        return 0; 
    }
}

int main()
{
    int day, month, year;
    int daysInMonth;

    printf("Enter day, month, and year (dd mm yyyy): ");
    scanf("%d %d %d", &day, &month, &year);

    switch (month) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            daysInMonth = 31;
            break;
        case 4: case 6: case 9: case 11:
            daysInMonth = 30;
            break;
        case 2:
            if (isLeapYear(year)) 
            {
                daysInMonth = 29;
            } else {
                daysInMonth = 28;
            }
            break;
        default:
            printf("Invalid month input.\n");
            return 1;
    }

    if (day < 1 || day > daysInMonth) {
        printf("Invalid day input.\n");
        return 1;
    }

    if (day < daysInMonth) {
        day++;
    } else {
        day = 1;
        if (month == 12) {
            month = 1;
            year++;
        } else {
            month++;
        }
    }

    printf("Next day's date: %d %d %d\n", day, month, year);

    return 0;
}
