//Program To Calculate Electricity Bill of A Customer

#include <stdio.h>

int main()
{
    int customerID;
    char customername[50];
    int units;
    float amount, surcharge = 0, totalAmount;
    float rate;

    printf("Input Customer ID: ");
    scanf("%d", &customerID);
    printf("Input Customer Name: ");
    scanf("%s", customername);
    printf("Input Units Consumed: ");
    scanf("%d", &units);

    if (units <= 199)
    {
        rate = 1.20;
        amount = units * rate;
    } 
    else if (units >= 200 && units < 400) 
    {
        rate = 1.50;
        amount = units * rate;
    } 
    else if (units >= 400 && units < 600) 
    {
        rate = 1.80;
        amount = units * rate;
    } else {
        rate = 2.00;
        amount = units * rate;
    }

    if (amount < 100)
    {
        amount = 100;
    }

    if (amount > 400)
    {
        surcharge = amount * 0.15;
    }

    totalAmount = amount + surcharge;

    printf("\nCustomer IDNO: %d\n", customerID);
    printf("Customer Name: %s\n", customername);
    printf("Unit Consumed: %d\n", units);
    printf("Amount Charges @Rs. %.2f per unit: %.2f\n", rate, amount);
    printf("Surcharge Amount: %.2f\n", surcharge);
    printf("Net Amount Paid by the Customer: %.2f\n", totalAmount);

    return 0;
}
