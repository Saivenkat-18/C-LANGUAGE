//Program To Display Height

#include <stdio.h>

int main()
{
    float height_cm, height_ft;

    printf("Enter the height of the person in centimeters: ");
    scanf("%f", &height_cm);

    height_ft = height_cm / 30.48;

    if (height_ft > 5.5) 
    {
        printf("The person is taller.\n");
    }
    else if (height_ft < 4.5)
    {
        printf("The person is a dwarf (low height).\n");
    }
    else 
    {
        printf("The person is of average height.\n");
    }

    return 0;
}


