//Program To Check Whether A Passenger is Eligible For Concession

#include <stdio.h>

int isEligibleForConcession(char gender, int age) 
{
    if ((gender == 'M' && age > 60) ||
        (gender == 'F' && age > 50) ||
        (age < 5))
        {
        return 1; 
    }
    return 0; 
}

int main() 
{
    char gender;
    int age;

    printf("Enter gender (M/F): ");
    scanf(" %c", &gender);
    printf("Enter age: ");
    scanf("%d", &age);

    if (isEligibleForConcession(gender, age))
    {
        if (age < 5)
        {
            printf("The passenger is eligible for full concession.\n");
        }
        else
        {
            printf("The passenger is eligible for a 50%% concession.\n");
        }
    }
    else 
    {
        printf("The passenger is not eligible for a concession.\n");
    }

    return 0;
}
