//Program To Calculate Discount And Final Amount

#include<stdio.h>

int main()

{
    float dis,billamt,sales;
    
    printf("Enter The Amount Of Sales : ");
    scanf("%f",&sales);
    
    if(sales>=25000)
    {
        dis=sales*10/100;
    }
    else
    {
        dis=sales*5/100;
    }
    
    billamt=sales-dis;
    
    printf("Discount Is %.2f ",dis);
    printf("\nTotal Bill Amount Is %.2f ",billamt);
    
}

