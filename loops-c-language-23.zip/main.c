#include <stdio.h>

int main()
{
    int i;

    printf("ASCII Chart:\n");
    printf("============\n");
    printf("Dec\tHex\tChar\n");
    printf("-------------------------\n");

    for (i = 0; i < 128; i++)
    {
      
        printf("%3d\t0x%02X\t", i, i);
        
        if (i >= 32 && i <= 126) {
            printf("%c\n", i);
        } else {
            printf(".\n"); 
        }
    }

    return 0;
}
