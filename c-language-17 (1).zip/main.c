//Program To Calculate Gross Salary and Net Salary From The Input Basic Salary,Allowances and Deductions

#include <stdio.h>

int main()
{
    float basicsalary, allowances, deductions;
    float grosssalary, netsalary;

    printf("Enter Basic Salary : ");
    scanf("%f", &basicsalary);

    printf("Enter Allowances : ");
    scanf("%f", &allowances);

    printf("Enter Deductions : ");
    scanf("%f", &deductions);

    grosssalary = basicsalary+allowances;
    
    netsalary = grosssalary-deductions;

    printf("Gross Salary : %.2f\n", grosssalary);
    printf("Net Salary : %.2f\n", netsalary);

    return 0;
}

