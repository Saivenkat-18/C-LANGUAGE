//Program To Read The Price Of 3 Pens And Displaying The Costliest

#include <stdio.h>

int main()
{
    float reynold, montex, parker;
    float maxprice;
    char costliestpen;

    printf("Enter the Price of Reynold Pen : ");
    scanf("%f", &reynold);

    printf("Enter the Price of Montex Pen : ");
    scanf("%f", &montex);

    printf("Enter the Price of Parker Pen : ");
    scanf("%f", &parker);

    maxprice = reynold;
    costliestpen = reynold;

    if (montex > maxprice) 
    {
        maxprice = montex;
        costliestpen = montex;
    }

    if (parker > maxprice)
    {
        maxprice = parker;
        costliestpen = parker;
    }

    printf("The Costliest Pen is %c with a Price of %.2f\n",costliestpen,maxprice);

    return 0;
}
