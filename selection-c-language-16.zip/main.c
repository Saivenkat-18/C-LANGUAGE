//Program To Check Whether The Inputted Character Is a Vowel or A Consonant

#include<stdio.h>

int main()

{
    char ch;
    
    printf("Enter A Character : ");
    scanf("%c",&ch);

    
    if(ch=='a'|| ch=='e'||ch=='i'||ch=='o'||ch=='u')
    printf("%c Is A Vowel",ch);
    else
    printf("%c Is A Consonant",ch);
    
    return 0;
}