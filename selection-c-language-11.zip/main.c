//Program To Read Cost Price and Selling Price and Calculating Profit or Loss

#include<stdio.h>

int main()

{
    float cp,sp,profitloss=0;
    
    printf("Enter Cost Price : ");
    scanf("%f",&cp);
    
    printf("Enter Selling Price : ");
    scanf("%f",&sp);
    
    profitloss=sp-cp;
     if(profitloss>0)
     {
         printf("Profit is : %.2f\n",profitloss);
     }
    else
    if(profitloss<0)
    {
        printf("Loss is : %.2f\n",-profitloss);
    }
    else
    {
        printf("No Profit,No Loss\n");
    }
    return 0;
}
