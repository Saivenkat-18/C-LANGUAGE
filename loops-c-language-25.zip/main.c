#include <stdio.h>
#include <string.h>

int main()
{
    char name[100];
    char choice;

    do {
     
        printf("Enter the name of the person: ");
        scanf("%s", name);

        int length = strlen(name);
        printf("The length of the name '%s' is: %d\n", name, length);

        printf("Do you want to enter another name? (Y/N): ");
        scanf(" %c", &choice);

    } 
    while (choice == 'Y' || choice == 'y');

    printf("Program terminated.\n");

    return 0;
}
