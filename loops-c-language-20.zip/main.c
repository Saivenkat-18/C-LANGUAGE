#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() 
{
    int i;
    int numbers[10];
    int max;

    srand(time(NULL));

    printf("Generated numbers:\n");
    for (i = 0; i < 10; i++) {
        numbers[i] = rand() % 100; 
        printf("%d ", numbers[i]);
    }
    printf("\n");

    max = numbers[0];
    for (i = 1; i < 10; i++) {
        if (numbers[i] > max) {
            max = numbers[i];
        }
    }

    printf("The largest number is: %d\n", max);

    return 0;
}
