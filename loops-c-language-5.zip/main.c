#include<stdio.h>

int main()

{
    int no,firstdig,lastdig,sum,temp;
    
    printf("Enter A Number : ");
    scanf("%d",&no);
    
    lastdig = no % 10;
   
   temp = no;
   while(temp>=10)
   {
       temp /= 10;
   }
    firstdig = temp;
    
    sum = firstdig + lastdig;
    
    printf("Sum of First and Last Digits is : %d\n",sum);
    
    return 0;
}