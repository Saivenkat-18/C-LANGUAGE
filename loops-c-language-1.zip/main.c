#include<stdio.h>

int main()

{
    int num,i;
    
    printf("Enter A Natural Number : ");
    scanf("%d",&num);
    
    if(num<=0)
    {
        printf("Enter A Positive Number\n");
        
    }
    
    printf("Natural Numbers from %d to 1 are :\n",num);
    for(i=num;i>=1;i--)
    {
        printf("%d\n",i);
        
    }
    return 0;
}