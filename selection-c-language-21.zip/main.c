//Program To Calculate Bonus Of An Employee

#include <stdio.h>

float calculateGrossSalary(float basicSalary, float allowances);
float calculateNetSalary(float grossSalary, float deductions);
float calculateBonus(float netSalary, int experience);

int main()
{
  
    float basicSalary, allowances, deductions;
    int experience;
    float grossSalary, netSalary, bonus;

    printf("Enter the basic salary: ");
    scanf("%f", &basicSalary);
    printf("Enter the allowances: ");
    scanf("%f", &allowances);
    printf("Enter the deductions: ");
    scanf("%f", &deductions);
    printf("Enter the experience (in years): ");
    scanf("%d", &experience);

    grossSalary = calculateGrossSalary(basicSalary, allowances);
    netSalary = calculateNetSalary(grossSalary, deductions);

    bonus = calculateBonus(netSalary, experience);

    printf("\nGross Salary: %.2f\n", grossSalary);
    printf("Net Salary: %.2f\n", netSalary);
    printf("Bonus: %.2f\n", bonus);

    return 0;
}

float calculateGrossSalary(float basicSalary, float allowances)
{
    return basicSalary + allowances;
}

float calculateNetSalary(float grossSalary, float deductions)
{
    return grossSalary - deductions;
}

float calculateBonus(float netSalary, int experience)
{
    if (experience > 5)
    {
        return 3 * netSalary;
    }
    else if (experience > 3)
    {
        return 2 * netSalary;
    } else
    {
        return netSalary;
    }
}

