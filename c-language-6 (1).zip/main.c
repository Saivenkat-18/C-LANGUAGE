//Program To Swap Values Of Two Variables Without Using 3rd Variable

#include <stdio.h>

int main() 
{
    int A,B;

    // Input
    printf("Enter value of A : ");
    scanf("%d",&A);
    printf("Enter value of B : ");
    scanf("%d",&B);

    // Swapping Two Numbers Without Using A Third Variable
    A = A + B;
    B = A - B;
    A = A - B;

    // Output
    printf("After Swapping :\n");
    printf("Value of A : %d\n",A);
    printf("Value of B : %d\n",B);

    return 0;
}


