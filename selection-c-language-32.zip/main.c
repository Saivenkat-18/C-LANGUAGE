//Program To Design An Application

#include <stdio.h>

void displayMenu()
{
    printf("Veg Khana Restaurant\n");
    printf("S.No  Items    Price\n");
    printf("1.    Idli     Rs. 25\n");
    printf("2.    Dosa     Rs. 50\n");
    printf("3.    Vada     Rs. 20\n");
    printf("4.    Upma     Rs. 25\n");
    printf("5.    Exit\n");
}

int main()
{
    int choice, quantity;
    float totalBill = 0.0;

    while (1)
    {
        displayMenu();

        printf("Which item to order (1-5): ");
        scanf("%d", &choice);

        if (choice == 5) {
            break;
        }

        printf("How many plates: ");
        scanf("%d", &quantity);

        switch (choice) 
        {
            case 1:
                totalBill += 25 * quantity;
                break;
            case 2:
                totalBill += 50 * quantity;
                break;
            case 3:
                totalBill += 20 * quantity;
                break;
            case 4:
                totalBill += 25 * quantity;
                break;
            default:
                printf("Invalid choice! Please select a valid item.\n");
                break;
        }
    }

    printf("Total bill: Rs. %.2f\n", totalBill);

    return 0;
}
