//Program To Read Days And Convert It Into Years,Months,Weeks and Days

#include <stdio.h>

int main() 
{
    //Input
    int daysinyear = 365;
    int daysinmonth = 30;  
    int daysinweek = 7;
    
    int totaldays, years, months, weeks, days;
    
    printf("Enter Number Of Days : ");
    scanf("%d", &totaldays);
    
    //To Calculate years
    years = totaldays / daysinyear;
    totaldays = totaldays % daysinyear;
    
    //To Calculate months
    months = totaldays / daysinmonth;
    totaldays = totaldays % daysinmonth;
    
    // Calculate weeks
    weeks = totaldays / daysinweek;
    days = totaldays % daysinweek;
    
    // Output the results
    printf("Years: %d\n", years);
    printf("Months: %d\n", months);
    printf("Weeks: %d\n", weeks);
    printf("Days: %d\n", days);
    
    return 0;
}
