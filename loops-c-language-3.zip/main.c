#include <stdio.h>

int main()
{
    int numbers[10];
    int esum , oddsum = 0;
    int ecount , oddcount = 0;

    printf("Enter 10 numbers :\n");
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &numbers[i]);

        if (numbers[i] % 2 == 0)
        {
            esum += numbers[i];
            ecount++;
        }
        else
        {
            oddsum += numbers[i];
            oddcount++;
        }
    }

    printf("Sum of even numbers: %d\n", esum);
    printf("Count of even numbers: %d\n", ecount);
    printf("Sum of odd numbers: %d\n", oddsum);
    printf("Count of odd numbers: %d\n", oddcount);

    return 0;
}