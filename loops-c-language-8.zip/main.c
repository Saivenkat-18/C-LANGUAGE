#include<stdio.h>

int main()

{
    int no,sum=0;
    
    printf("Enter A Number : ");
    scanf("%d",&no);
    
    for(int i = 1;i <= no/2;i++)
    {
        if(no%i==0)
        {
            sum += i;
        }
    }
    
    if(sum==no && no!=0)
    {
        printf("%d is a Perfect Number.\n",no);
    }
    else
    {
        printf("%d is not a Perfect Number.\n",no);
    }
    
    return 0;
}