//Program To Evaluate (a+b)^2

#include<stdio.h>

int main()

{
    float a,b,result;
    
    printf("Enter The Value Of a : ");
    scanf("%f",&a);
    
    printf("Enter Value Of b : ");
    scanf("%f",&b);
    
    result=(a*a)+(b*b)+2*a*b;
    
    printf("The Result Of (a+b)^2 Is : %.2f\n",result);
    
    return 0;
}