//Program To Display 3 Characters In Reverse Order

#include <stdio.h>

int main()
{
    char a,b,c;
    
    // Input
    printf("Enter three characters separated by spaces: ");
    
    // Process
    scanf(" %c %c %c", &a, &b, &c);
    
    // Output
    printf("Reversed order: %c %c %c\n", c,b,a);
    
    return 0;
}


