//Program To Check whether The Person Is Eligible Foe Bonus or Not

#include <stdio.h>

int isEligibleForBonus(char gender, int age, int isMarried)
{
    if ((gender == 'M' && age > 60) ||
        (gender == 'M' && age > 30 && !isMarried) ||
        (gender == 'F' && age > 25 && !isMarried))
        {
        return 1;
        }
    return 0; 
}

int main()
{
    char gender;
    int age, isMarried;

    printf("Enter gender (M/F): ");
    scanf(" %c", &gender);
    printf("Enter age: ");
    scanf("%d", &age);
    printf("Enter marital status (1 for married, 0 for unmarried): ");
    scanf("%d", &isMarried);

    if (isEligibleForBonus(gender, age, isMarried)) 
    {
        printf("The person is eligible for a bonus.\n");
    }
    else 
    {
        printf("The person is not eligible for a bonus.\n");
    }

    return 0;
}
