#include<stdio.h>

int main()

{
    char name;
    int no=1,count;
    count=0;
    
    printf("Enter Your Name : ");
    scanf("%s",&name);
    
    printf("Enter 12 Digit Aadhar Number : ");
    scanf("%d",&no);
    
    while(no=0)
    
    {
        no = no/12;
        count++;
    }
    
    if(count==12)
      printf("It Is A Valid Aadhar Number");
      
      else
      printf("It Is An Invalid Number");
      
      return 0;
    
}