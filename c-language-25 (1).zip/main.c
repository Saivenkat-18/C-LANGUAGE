//To Calculate Area Of A Right Angled Triangle

#include<stdio.h>

int main()
{
    float base, height, area;

    printf("Enter the Length of Base of the Right Angled Triangle : ");
    scanf("%f", &base);

    printf("Enter the Height of Right Angled Triangle : ");
    scanf("%f", &height);

    area = 0.5 * base * height;

    printf("Area of the Right Angled Triangle : %.2f square units\n", area);

    return 0;
}