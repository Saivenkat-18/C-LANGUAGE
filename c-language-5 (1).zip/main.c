//Program To Display Gross Salary and Net Salary

#include <stdio.h>

int main()
{
    double basicsalary, hra, da, pf, grosssalary, netsalary;

    // Input 
    printf("Enter Basic Salary : ");
    scanf("%lf", &basicsalary);
    
    // Process
    hra = 0.20 * basicsalary; 
    da = 0.10 * basicsalary;  
    pf = 0.05 * basicsalary;  

    grosssalary = basicsalary + hra + da;
    netsalary = grosssalary - pf;

    // Output
    printf("Basic Salary : %.2lf\n", basicsalary);
    printf("HRA (20%%) : %.2lf\n", hra);
    printf("DA (10%%) : %.2lf\n", da);
    printf("PF (5%%) : %.2lf\n", pf);
    printf("Gross Salary : %.2lf\n", grosssalary);
    printf("Net Salary : %.2lf\n", netsalary);

    return 0;
}


