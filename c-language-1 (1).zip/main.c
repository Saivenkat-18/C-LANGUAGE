//To Print Name,DOB,Phone Number

#include <stdio.h>

main()
{
    //To Print Name
    printf("Enter Your Name: RAJ JAIN\n");
    
    //To Print DOB
    printf("Enter Your DOB: Feb 20,2002\n");
    
    //To Print Mobile Number
    printf("Enter Your Mobile Number :9949128444\n");
    
}

