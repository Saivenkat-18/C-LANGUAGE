//Program To Find Biggest Of Two Numbers

#include <stdio.h>

int main() 
{
    int n1, n2, n3, n4;
    int largestnum;

    printf("Enter Four Numbers : \n");
    scanf("%d %d %d %d", &n1, &n2, &n3, &n4);

    largestnum = n1;

    if (n2 > largestnum)
    {
        largestnum = n2;
    }

    if (n3 > largestnum) 
    {
        largestnum = n3;
    }

    if (n4 > largestnum)
    {
        largestnum = n4;
    }

    printf("The Largest Number is : %d\n", largestnum);

    return 0;
}