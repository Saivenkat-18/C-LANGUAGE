#include <stdio.h>

int sumOfDigits(int num)
{
    int sum = 0;
    while (num > 0) 
    {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}

void findGemstone(int luckyNumber)
{
    switch (luckyNumber)
    {
        case 1:
            printf("Your suitable gemstone: Ruby\n");
            break;
        case 2:
            printf("Your suitable gemstone: Moonstone\n");
            break;
        case 3:
            printf("Your suitable gemstone: Amethyst\n");
            break;
        case 4:
            printf("Your suitable gemstone: Topaz\n");
            break;
        case 5:
            printf("Your suitable gemstone: Emerald\n");
            break;
        case 6:
            printf("Your suitable gemstone: Turquoise\n");
            break;
        case 7:
            printf("Your suitable gemstone: Onyx\n");
            break;
        case 8:
            printf("Your suitable gemstone: Jade\n");
            break;
        case 9:
            printf("Your suitable gemstone: Sapphire\n");
            break;
        default:
            printf("Your suitable gemstone: Diamond\n");
    }
}

int main()
{
    char dob[9];
    int luckyNumber = 0;

    printf("Enter your date of birth in MMDDYYYY format: ");
    scanf("%s", dob);

    for (int i = 0; i < 8; i++) 
    {
        luckyNumber += dob[i] - '0'; 
    }

    while (luckyNumber > 9)
    {
        luckyNumber = sumOfDigits(luckyNumber);
    }

    printf("Your lucky number: %d\n", luckyNumber);

    findGemstone(luckyNumber);

    return 0;
}
