//Program To Calculate Electricity From Inputted Present Month and Last Month Reading

#include<stdio.h>

int main()

{
    
    float presentreading,lastreading,unitsconsumed,rateperunit,billamt;
    
    printf("Enter Present Month Reading : ");
    scanf("%f",&presentreading);
    
    printf("Enter Last Months Reading : ");
    scanf("%f",&lastreading);
    
    printf("Enter Rate Per Unit Of Electricity : ");
    scanf("%f",&rateperunit);
    
    unitsconsumed=presentreading-lastreading;
    
    billamt=unitsconsumed*rateperunit;
    
    printf("Units Consumed : %.2f\n",unitsconsumed);
    printf("Total Bill Amount : %.2f\n",billamt);
    
    return 0;
}

