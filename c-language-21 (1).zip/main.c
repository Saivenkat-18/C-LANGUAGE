//Program To Display How To Split Bill Among no of People

#include<stdio.h>

int main()

{
    float billamount, tippercent, totalamount, amountperperson;
    int numfriends,tipchoice;

    // Input the total bill amount
    printf("Enter The Total Bill Amount : ");
    scanf("%f", &billamount);

    // Input the number of friends
    printf("Enter The Number Of Friends : ");
    scanf("%d", &numfriends);

    // Choose the tip percentage
    printf("Choose The Tip Percentage (1 for 5%%,2 for 10%%) : ");
    scanf("%d", &tipchoice);

   if (tipchoice == 1)
    {
        tippercent = 0.05;
    } else if (tipchoice == 2)
    {
        tippercent = 0.10;
    } else
    {
        printf("Invalid Choice! Defaulting to 5%% tip.\n");
        tippercent = 0.05;
    }
    
    totalamount = billamount + (billamount * tippercent);

    amountperperson = totalamount / numfriends;
    
    printf("Total Bill Amount (including tip): %.2f\n", totalamount);
    printf("Each Person Should Pay: %.2f\n", amountperperson);

    return 0;
}
